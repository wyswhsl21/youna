import React, { useEffect, useState } from "react";
import styled from "styled-components";
import axios from "axios";

const Calculator = () => {
  const [info, setInfo] = useState([]);
  const [input, setInput] = useState("");
  const [exchangeInput, setExchangeInput] = useState();
  const [exchange, setExchange] = useState();
  const [dropdown, setDropdown] = useState([""]);
  const [seDropdown, setSeDropdown] = useState([""]);
  const [country, setCountry] = useState([]);
  const [value, setValue] = useState("");
  const [secondValue, setSecondValue] = useState("");

  useEffect(() => {
    async function getCurrency() {
      const { data } = await axios.get(
        "https://api.exchangerate.host/latest?base=USD"
      );
      setCountry(data.rates);
    }
    console.log(input);

    getCurrency();
  }, []);
  //country 배열로 만들기

  //input change Handler
  const inputHandleChange = (e) => {
    setInput(e.target.value);

    setExchangeInput(e.target.value * country[value]);

    // console.log(dropdown);
  };
  // 위에 select 박스 onchangeHandler
  const selectHandleChange = (e) => {
    setValue(e.target.value);
    setExchangeInput(input / country[value]);
  };
  // console.log(value);

  // 위에 select 박스 onclickHandler
  const countryHandleChange = () => {
    for (let c in country) {
      // console.log(c);
    }

    let arr = Object.entries(country).map((item) => item[0]);

    setDropdown(arr);

    // for (let c in country) {
    //   setDropdown(c);
    // }
  };
  // 아래 select 박스 onchangeHandler
  const selectExchangeHandler = (e) => {
    setSecondValue(e.target.value);
    console.log(secondValue);
  };
  // 아래 select 박스 onclickHandler
  const exChangeCountryHandleler = () => {
    for (let a in country) {
      console.log(a);
    }
    let arr2 = Object.entries(country).map((item) => item[0]);
  };

  // console.log(country);
  return (
    <>
      <Header>
        <CalDiv>
          <CalInput name="amount" value={input} onChange={inputHandleChange} />
          <select
            onChange={(e) => selectHandleChange(e)}
            onClick={countryHandleChange}
            style={{ width: "300px", height: "50px" }}
          >
            {dropdown.map((item, index) => (
              <option key={index}>{item}</option>
            ))}
          </select>
        </CalDiv>
        <ExchangeDiv>
          <ExchangeInput
            value={exchangeInput}
            onChange={() => setExchangeInput()}
          />
          <select
            onChange={(e) => selectExchangeHandler(e)}
            onClick={exChangeCountryHandleler}
            style={{ width: "300px", height: "50px" }}
          >
            {dropdown.map((item, index) => (
              <option key={index}>{item}</option>
            ))}
          </select>
        </ExchangeDiv>
      </Header>
    </>
  );
};

export default Calculator;
const Header = styled.div`
  margin: auto;
  width: 100vw;
  height: 100vh;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
`;
const CalInput = styled.input`
  width: 100px;
  height: 59px;
`;
const ExchangeInput = styled.input`
  width: 100px;
  height: 59px;
`;
const CalDiv = styled.div`
  width: 300px;
  height: 80px;
  background-color: none;
  border: black;
  display: flex;
  flex-direction: row;
`;
const ExchangeDiv = styled.div`
  width: 300px;
  height: 80px;
  display: flex;
  flex-direction: row;
`;
