import Router from "./Shared/Router";
import React from "react";

const App = () => {
  return (
    <div>
      <Router />
    </div>
  );
};

export default App;
